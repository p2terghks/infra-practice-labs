#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
LAB_PORT="${LAB_PORT:-8080}"
printf 'Kubernetes 실습실: http://127.0.0.1:%s\n종료: Ctrl+C\n' "$LAB_PORT"
exec python3 -m http.server "$LAB_PORT" --bind 127.0.0.1 --directory public
