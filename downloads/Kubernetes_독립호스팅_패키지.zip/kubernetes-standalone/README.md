# Kubernetes 실습실 · 독립 호스팅 패키지

이 패키지는 Kubernetes 학습 웹의 독립 실행판입니다. ChatGPT 로그인, Sites 호스팅, API 키, 별도 백엔드, Node.js 설치나 빌드 과정 없이 동작합니다.

학습 화면은 브라우저에서만 실행됩니다. 실제 kubectl·클러스터 API는 호출하지 않습니다. YAML 따라치기 10단계, 앱 연결 8단계, 장애 진단 6가지를 포함합니다.

## 가장 빠른 시작

인터넷 없이 파일 하나로 연습하려면 `offline.html`을 브라우저에서 여세요. 공식 문서 링크와 실제 이미지 다운로드에는 인터넷이 필요합니다. 브라우저가 로컬 파일 저장을 제한하면 입력·진도는 현재 탭에서만 유지될 수 있습니다.

안정적인 진도 저장과 배포 확인을 위해서는 아래 로컬 서버 방식을 사용하세요.

## 폴더 구조

```text
kubernetes-standalone/
├── public/                 # 실제 호스팅할 웹 파일: 이 폴더 내용을 업로드
│   ├── index.html
│   ├── data.js             # 학습 예제·문제·연결 앱 YAML
│   ├── kube.js             # 입력 비교·퀴즈·진도 저장
│   └── *.css               # 화면 스타일
├── offline.html            # CSS·JS를 포함한 단일 HTML
├── start.sh                # Python 로컬 서버 실행
├── Dockerfile              # 선택: Nginx 컨테이너
├── nginx.conf              # 위 컨테이너의 8080 서버 설정
├── compose.yaml            # 선택: 로컬 Docker 실행
├── examples/               # 학습용 Kubernetes 앱 파일
├── MANIFEST.sha256         # 파일 무결성 확인용 목록
└── README.md
```

## 방법 1 · Python 로컬 서버

Python 3가 설치된 상태에서 ZIP을 풀고 패키지 폴더에서 실행합니다.

```bash
python3 -m http.server 8080 --bind 127.0.0.1 --directory public
```

브라우저에서 `http://127.0.0.1:8080`을 엽니다. 종료는 Ctrl+C입니다. macOS·Linux에서는 `bash start.sh`로도 실행할 수 있습니다. 8080이 사용 중이면 포트를 8081로 바꾸세요.

Windows에서 python3가 없으면 다음처럼 실행합니다.

```text
py -3 -m http.server 8080 --bind 127.0.0.1 --directory public
```

Python 서버는 로컬 확인용입니다. 외부 운영 호스팅은 정적 호스팅 서비스나 웹 서버를 사용하세요.

## 방법 2 · 원하는 정적 호스팅에 업로드

`public/` 안의 파일 7개를 폴더 구조 그대로 웹 루트에 올립니다.

- 시작 파일: `index.html`
- 빌드 명령: 없음
- 배포할 디렉터리: `public`
- 환경 변수·서버 함수·데이터베이스: 필요 없음
- 모든 상대 경로를 유지하므로 `/k8s/` 같은 하위 디렉터리에도 배치 가능
- 서버가 `.js`를 JavaScript, `.css`를 CSS MIME 형식으로 제공해야 함

디렉터리 기반 업로드 서비스라면 public 폴더를 지정하고, 웹 루트에 직접 복사하는 방식이라면 public 내부의 파일을 복사합니다. Dockerfile·README·examples는 학습 사이트를 제공하는 데 필요하지 않습니다.

이 앱은 클라이언트 라우팅을 사용하지 않습니다. 알 수 없는 경로를 index.html로 바꾸는 SPA fallback은 필요하지 않습니다. 오래된 화면이 보이면 HTML·JS·CSS 캐시를 갱신하고 함께 다시 업로드하세요.

## 방법 3 · Docker / Nginx

Docker 엔진과 Compose가 실행 중인 컴퓨터에서 패키지 루트에서 실행합니다. 처음에는 공개 베이스 이미지를 내려받을 인터넷 연결이 필요합니다.

```bash
docker compose up -d --build
```

접속: `http://127.0.0.1:8080`

```bash
# 로그 확인
docker compose logs --tail=50
# Nginx 설정 확인
docker compose exec web nginx -t
# 종료·컨테이너 정리
docker compose down
```

Compose 없이 실행할 수도 있습니다.

```bash
docker build -t kubernetes-practice .
docker run --rm --name kubernetes-practice -p 127.0.0.1:8080:8080 kubernetes-practice
```

공식 NGINX 프로젝트의 비특권 이미지를 사용하며 컨테이너는 8080에서 수신합니다. Compose는 기본적으로 로컬 루프백에만 포트를 연결합니다. 원격 서버에서 외부 사용자에게 제공하려면 해당 서버의 도메인·HTTPS·역방향 프록시·접근 범위에 맞게 연결하세요. `stable-alpine`은 갱신 가능한 태그이므로 재현성을 고정하려면 검증한 이미지 digest로 바꿉니다.

## 로그인·진도 저장

- 파일 자체에는 로그인 기능이 없습니다. 기존 호스팅의 본인 전용 접근 제어는 이 파일에 포함되는 기능이 아닙니다.
- 접근을 제한할 사이트라면 새 호스팅이나 앞단 프록시에서 인증을 설정합니다.
- 입력과 완료 기록은 브라우저 localStorage에 저장됩니다. 서버로 전송하지 않습니다.
- 저장 키는 `kubernetes-typing-lab-v1`입니다.
- 도메인·포트·브라우저가 바뀌면 저장 공간이 달라집니다. 기존 사이트의 진도가 자동으로 이전되지는 않습니다.
- 공유 PC에서는 사용자 계정별 진도 분리가 아닌 같은 브라우저 프로필의 저장소를 사용합니다.
- 실제 토큰·Secret·kubeconfig를 학습 입력에 넣지 마세요.

## 내용 수정

`public/data.js`에서 예제·문제·연결 단계를 수정하고, `public/kube.js`에서 입력 비교와 화면 동작을 수정합니다. 스타일은 `public/*.css`에 있습니다.

`offline.html`은 생성 시점의 복사본입니다. public을 수정한 뒤 파일 하나로 다시 묶으려면 아래 명령을 실행하세요.

```bash
python3 build_offline.py
```

## 학습용 YAML과 호스팅 파일 구분

`examples/app.yaml`은 Kubernetes 수업에서 배포해 보는 Nginx 데모 앱입니다. Kubernetes 실습실 웹 자체를 배포하는 매니페스트가 아닙니다.

기본 예제는 Namespace·ConfigMap·가짜 Secret·Deployment·ClusterIP Service 5개입니다. Ingress는 별도 파일이며 호환되는 컨트롤러가 필요합니다. 실제 적용 전 kubectl context와 전용 네임스페이스를 확인합니다.

## 검증 범위

독립 파일의 JavaScript 구문, 상대 경로와 패키지 구성, 로컬 HTTP 제공과 주요 학습 동작을 확인했습니다. Docker 엔진이 실행 중이 아니어서 컨테이너 이미지 빌드·Nginx 실행 검증은 수행하지 못했습니다. 실제 Kubernetes 클러스터 배포도 수행하지 않았습니다.

## 공식 문서

- [NGINX 비특권 이미지와 포트·레지스트리](https://github.com/nginx/docker-nginx-unprivileged)
- [Docker 포트 공개와 로컬 바인딩](https://docs.docker.com/get-started/docker-concepts/running-containers/publishing-ports/)
- [NGINX try_files](https://nginx.org/en/docs/http/ngx_http_core_module.html#try_files)

분리일: 2026-11-13
