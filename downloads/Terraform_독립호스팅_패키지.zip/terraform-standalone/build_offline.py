from pathlib import Path
import re

root = Path(__file__).resolve().parent
public = root / "public"
text = (public / "index.html").read_text(encoding="utf-8")
text = re.sub(r'<link rel="stylesheet" href="([^\"?]+)(?:\?[^\"]*)?">', lambda m: "<style>\n" + (public / m[1]).read_text(encoding="utf-8") + "\n</style>", text)
text = re.sub(r'<script src="([^\"?]+)(?:\?[^\"]*)?"></script>', lambda m: "<script>\n" + (public / m[1]).read_text(encoding="utf-8") + "\n</script>", text)
(root / "offline.html").write_text(text, encoding="utf-8")
print("offline.html 생성 완료")
